
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `collaborations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collaborations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `primary_user_id` bigint unsigned DEFAULT NULL,
  `secondary_user_id` bigint unsigned DEFAULT NULL,
  `correspondence_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `collaborations_primary_user_id_foreign` (`primary_user_id`),
  KEY `collaborations_secondary_user_id_foreign` (`secondary_user_id`),
  KEY `collaborations_correspondence_id_foreign` (`correspondence_id`),
  CONSTRAINT `collaborations_correspondence_id_foreign` FOREIGN KEY (`correspondence_id`) REFERENCES `correspondences` (`id`),
  CONSTRAINT `collaborations_primary_user_id_foreign` FOREIGN KEY (`primary_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `collaborations_secondary_user_id_foreign` FOREIGN KEY (`secondary_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `collaborations` WRITE;
/*!40000 ALTER TABLE `collaborations` DISABLE KEYS */;
/*!40000 ALTER TABLE `collaborations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `correspondences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `correspondences` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fechaCreacion` date NOT NULL,
  `hojaDeRuta` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estadoAnterior` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documento_inicial` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receptor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `tipo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `fechaEntregado` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `correspondences_unit_id_foreign` (`unit_id`),
  KEY `correspondences_user_id_foreign` (`user_id`),
  CONSTRAINT `correspondences_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`),
  CONSTRAINT `correspondences_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `correspondences` WRITE;
/*!40000 ALTER TABLE `correspondences` DISABLE KEYS */;
/*!40000 ALTER TABLE `correspondences` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombreDocumento` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fechaSubida` date NOT NULL,
  `correspondence_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_correspondence_id_foreign` (`correspondence_id`),
  KEY `documents_user_id_foreign` (`user_id`),
  CONSTRAINT `documents_correspondence_id_foreign` FOREIGN KEY (`correspondence_id`) REFERENCES `correspondences` (`id`) ON DELETE CASCADE,
  CONSTRAINT `documents_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `interesteds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interesteds` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `money_boxes_id` bigint unsigned DEFAULT NULL,
  `nombreCompleto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `interesteds_money_boxes_id_foreign` (`money_boxes_id`),
  CONSTRAINT `interesteds_money_boxes_id_foreign` FOREIGN KEY (`money_boxes_id`) REFERENCES `money_boxes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `interesteds` WRITE;
/*!40000 ALTER TABLE `interesteds` DISABLE KEYS */;
INSERT INTO `interesteds` VALUES (1,1,'Walter Bustillos','2024-04-05 23:53:45','2024-04-05 23:53:45'),(2,1,'Simon Pacosillo Ticona','2024-04-05 23:53:45','2024-04-05 23:53:45');
/*!40000 ALTER TABLE `interesteds` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventories` WRITE;
/*!40000 ALTER TABLE `inventories` DISABLE KEYS */;
INSERT INTO `inventories` VALUES (1,'Inventario','2024-04-05 23:53:42','2024-04-05 23:53:42');
/*!40000 ALTER TABLE `inventories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `materials` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `inventory_id` bigint unsigned DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cantidad_disponible` int NOT NULL,
  `cantidad_utilizada` int NOT NULL,
  `estado` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imagen` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `materials_inventory_id_foreign` (`inventory_id`),
  CONSTRAINT `materials_inventory_id_foreign` FOREIGN KEY (`inventory_id`) REFERENCES `inventories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `materials` WRITE;
/*!40000 ALTER TABLE `materials` DISABLE KEYS */;
INSERT INTO `materials` VALUES (1,1,'Control de data',5,4,'disponible','Control del data que sirve para el manejo de los datas instalados en las aulas.','control.jpg','2024-04-05 23:53:42','2024-04-06 01:15:08'),(2,1,'Parlantes',1,1,'disponible','Parlantes de computadora, son pequeños y vienen en pares.','parlantes.jpg','2024-04-05 23:53:42','2024-04-05 23:53:42'),(3,1,'Laptop',3,3,'disponible','Computadora de escritorio movil, esencial para las clases de los docentes.','laptop.jpg','2024-04-05 23:53:42','2024-04-05 23:53:42'),(4,1,'Proyector',1,1,'disponible','Conocido como data mayormente.','data.png','2024-04-05 23:53:42','2024-04-05 23:53:42'),(5,1,'Carlitos',1,1,'disponible','Esqueleto casi tamaño real para aprendizaje','carlitos.jpg','2024-04-05 23:53:42','2024-04-05 23:53:42'),(6,1,'Cable vga',1,1,'disponible','Utilizado para conectar entre un data y una computadora','cablevga.jpg','2024-04-05 23:53:42','2024-04-05 23:53:42');
/*!40000 ALTER TABLE `materials` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mentions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mentions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mentions` WRITE;
/*!40000 ALTER TABLE `mentions` DISABLE KEYS */;
INSERT INTO `mentions` VALUES (1,'Bioimagenología','2024-04-05 23:53:41','2024-04-05 23:53:41'),(2,'Laboratorio clínico','2024-04-05 23:53:41','2024-04-05 23:53:41'),(3,'Fisioterapia y Kinesiología','2024-04-05 23:53:41','2024-04-05 23:53:41');
/*!40000 ALTER TABLE `mentions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2024_01_24_182016_student',1),(6,'2024_01_24_191957_mention',1),(7,'2024_01_24_192351_create_teachers_table',1),(8,'2024_01_24_193103_create_subjects_table',1),(9,'2024_01_24_193316_create_teacher_subjects_table',1),(10,'2024_01_24_193803_add_column_subject_table',1),(11,'2024_01_24_194056_create_teacher_mentions_table',1),(12,'2024_01_24_194330_add_column_student_table',1),(13,'2024_01_24_222705_create_inventories_table',1),(14,'2024_01_24_222756_create_materials_table',1),(15,'2024_01_25_192803_create_orders_table',1),(16,'2024_01_25_193439_create_order_materials_table',1),(17,'2024_01_26_021835_add_cantidad',1),(18,'2024_01_26_044629_add_column_on_orders',1),(19,'2024_01_26_184926_add_column_on__order',1),(20,'2024_01_29_194216_create_correspondences_table',1),(21,'2024_01_29_194758_create_units_table',1),(22,'2024_01_29_231227_add_column_on_correspondences',1),(23,'2024_02_01_183117_create_money_boxes_table',1),(24,'2024_02_01_183919_create_spents_table',1),(25,'2024_02_01_203551_create_interesteds_table',1),(26,'2024_02_01_204946__add_column_to_spents',1),(27,'2024_02_10_210734_add_column_to_money_box',1),(28,'2024_02_17_220930_create_collaborations_table',1),(29,'2024_02_18_051007_create_documents_table',1),(30,'2024_02_18_051132_create_responses_table',1),(31,'2024_02_18_051440_add_rows_to_table',1),(32,'2024_02_22_012056_add_column_responses',1),(33,'2024_02_25_232710_add_column_money_box',1),(34,'2024_02_26_020119_create_recharges_table',1),(35,'2024_03_03_185717_add_column_to_correspondence',1),(36,'2024_03_04_192244_add_column_recharges',1),(37,'2024_03_05_160552_add_column_recharges',1),(38,'2024_03_07_152533__add_column_to_spents',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `money_boxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `money_boxes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `director_user_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `money_boxes_user_id_foreign` (`user_id`),
  KEY `money_boxes_director_user_id_foreign` (`director_user_id`),
  CONSTRAINT `money_boxes_director_user_id_foreign` FOREIGN KEY (`director_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `money_boxes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `money_boxes` WRITE;
/*!40000 ALTER TABLE `money_boxes` DISABLE KEYS */;
INSERT INTO `money_boxes` VALUES (1,'Caja Chica I',1000.00,'2024-04-05 23:53:45','2024-04-05 23:53:45',NULL,NULL);
/*!40000 ALTER TABLE `money_boxes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_materials` (
  `order_id` bigint unsigned DEFAULT NULL,
  `material_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cantidad` int NOT NULL,
  KEY `order_materials_order_id_foreign` (`order_id`),
  KEY `order_materials_material_id_foreign` (`material_id`),
  CONSTRAINT `order_materials_material_id_foreign` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`),
  CONSTRAINT `order_materials_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_materials` WRITE;
/*!40000 ALTER TABLE `order_materials` DISABLE KEYS */;
INSERT INTO `order_materials` VALUES (1,1,'2024-04-06 01:15:08','2024-04-06 01:15:08',1);
/*!40000 ALTER TABLE `order_materials` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `teacher_id` bigint unsigned DEFAULT NULL,
  `subject_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_user_id_foreign` (`user_id`),
  KEY `orders_teacher_id_foreign` (`teacher_id`),
  KEY `orders_subject_id_foreign` (`subject_id`),
  CONSTRAINT `orders_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`),
  CONSTRAINT `orders_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`),
  CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,4,6,10,'2024-04-06 01:15:08','2024-04-06 01:15:08','Sin habilitar',NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (6,'App\\Models\\User',3,'token','819f6458c0e18706202c8192dd771760cad460b4a906b9dd26852a4736d6fb0f','[\"*\"]','2024-04-06 00:28:39',NULL,'2024-04-06 00:15:25','2024-04-06 00:28:39'),(7,'App\\Models\\User',3,'token','2ab59fb66646705b91a9414a7036dd40b4e4e8b4ea8eb7f9f4b67ffd3b16a91e','[\"*\"]','2024-04-06 00:49:46',NULL,'2024-04-06 00:28:50','2024-04-06 00:49:46'),(11,'App\\Models\\User',3,'token','0c47616d4ccb61f6951cb231fed1421c2d1fce64c577e6b9fa27d2b431c31dd4','[\"*\"]','2024-04-06 01:16:59',NULL,'2024-04-06 01:01:26','2024-04-06 01:16:59');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `recharges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recharges` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `estado` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `money_box_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `montoRecarga` decimal(6,2) DEFAULT NULL,
  `fechaRecarga` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recharges_money_box_id_foreign` (`money_box_id`),
  CONSTRAINT `recharges_money_box_id_foreign` FOREIGN KEY (`money_box_id`) REFERENCES `money_boxes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `recharges` WRITE;
/*!40000 ALTER TABLE `recharges` DISABLE KEYS */;
/*!40000 ALTER TABLE `recharges` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `responses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `response` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `document_id` bigint unsigned DEFAULT NULL,
  `correspondence_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_secondary_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `responses_document_id_foreign` (`document_id`),
  KEY `responses_correspondence_id_foreign` (`correspondence_id`),
  KEY `responses_user_id_foreign` (`user_id`),
  KEY `responses_user_secondary_id_foreign` (`user_secondary_id`),
  CONSTRAINT `responses_correspondence_id_foreign` FOREIGN KEY (`correspondence_id`) REFERENCES `correspondences` (`id`),
  CONSTRAINT `responses_document_id_foreign` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`),
  CONSTRAINT `responses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `responses_user_secondary_id_foreign` FOREIGN KEY (`user_secondary_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `responses` WRITE;
/*!40000 ALTER TABLE `responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `responses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `spents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `spents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `money_boxes_id` bigint unsigned DEFAULT NULL,
  `fechaCreacion` date NOT NULL,
  `nro` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nroFactura` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gasto` decimal(6,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `interested_id` bigint unsigned NOT NULL,
  `ingreso` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `spents_money_boxes_id_foreign` (`money_boxes_id`),
  KEY `spents_interested_id_foreign` (`interested_id`),
  CONSTRAINT `spents_interested_id_foreign` FOREIGN KEY (`interested_id`) REFERENCES `interesteds` (`id`),
  CONSTRAINT `spents_money_boxes_id_foreign` FOREIGN KEY (`money_boxes_id`) REFERENCES `money_boxes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `spents` WRITE;
/*!40000 ALTER TABLE `spents` DISABLE KEYS */;
/*!40000 ALTER TABLE `spents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `mention_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `students_user_id_foreign` (`user_id`),
  KEY `students_mention_id_foreign` (`mention_id`),
  CONSTRAINT `students_mention_id_foreign` FOREIGN KEY (`mention_id`) REFERENCES `mentions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `students_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,4,'1778610','2024-04-06 01:13:32','2024-04-06 01:13:32',2);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subjects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `mention_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `subjects_mention_id_foreign` (`mention_id`),
  CONSTRAINT `subjects_mention_id_foreign` FOREIGN KEY (`mention_id`) REFERENCES `mentions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,'Metodología de la investigación','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(2,'Informática aplicada','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(3,'Inglés técnico','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(4,'Anatomía humana normal','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(5,'Embriología y genética','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(6,'Histología básica normal','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(7,'Primeros auxilios','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(8,'Introduccion a la Bio-imagenología','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(9,'Fisica de las radiaciones','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(10,'Bioestadística','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(11,'Fisiología y biofísica','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(12,'Bioquímica aplicada','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(13,'Farmacología aplicada','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(14,'Patología general','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(15,'Radiobiología y protección radiológica','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(16,'Radiologia I','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(17,'Mamografía y densitometría ósea','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(18,'Anatomía radiológica I','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(19,'Semiología radiologíca aplicada','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(20,'Salud pública y epidemiología','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(21,'Psicología aplicada','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(22,'Administración y gestion en salud','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(23,'Radiología II','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(24,'Radiología dental - maxilofacial','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(25,'Radiología veterinaria','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(26,'Anatomía Radiológica II','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(27,'Tomografía','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(28,'Resonancia magnética nuclear','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(29,'Ultrasonografía','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(30,'Medicina nuclear','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(31,'Radioterapia','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(32,'Radiología Pediátrica','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(33,'Deontología y radiología forense','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(34,'Electromedicina aplicada','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(35,'Radiología intervencionista','2024-04-05 23:53:41','2024-04-05 23:53:41',1),(36,'Anatomica humana basica','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(37,'Biologia y genetica','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(38,'Bioquímica','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(39,'Fisiología humana - biofisica','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(40,'Histología','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(41,'Introducción a laboratorio','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(42,'Primeros auxilios','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(43,'Quimíca inorganica y organica','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(44,'Salud publica','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(45,'Cipatología','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(46,'Hematología','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(47,'Inmunología','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(48,'Micología','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(49,'Microbiología','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(50,'Parasitología','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(51,'Patología clinica','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(52,'Patología general','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(53,'Tecnicas de patología','2024-04-05 23:53:41','2024-04-05 23:53:41',2),(54,'Anatomia funcional','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(55,'Metodología de la investigación I','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(56,'Fisiología aplicada','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(57,'Histología aplicada','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(58,'Primeros auxilios','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(59,'Embriología','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(60,'Electroterapia','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(61,'Nosología clínica','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(62,'Fisioterapia general','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(63,'Cinesiterapia','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(64,'Kinesiología','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(65,'Mecanoterapia','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(66,'Bioquímica aplicada','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(67,'Neurología evolutiva y psicomotricidad','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(68,'Técnicas kinesicas especiales I','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(69,'Técnicas kinesicas especiales II','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(70,'Farmacología aplicada','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(71,'Biomecánica','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(72,'Imagenología aplicada','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(73,'Semiopatología kinésica','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(74,'Ergonomía funcional','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(75,'Fisioterapia aplicada I','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(76,'Fisioterapia aplicada II','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(77,'Gerencia y administración en salud','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(78,'Rehabilitación en base a la comunidad','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(79,'Metodología de la investigación II','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(80,'Técnicas de revitalización geriatrica','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(81,'Terapias alternativas','2024-04-05 23:53:41','2024-04-05 23:53:41',3),(82,'Fisioterapia del deporte y la actividad física','2024-04-05 23:53:41','2024-04-05 23:53:41',3);
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `teacher_mentions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teacher_mentions` (
  `teacher_id` bigint unsigned NOT NULL,
  `mention_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `teacher_mentions_teacher_id_foreign` (`teacher_id`),
  KEY `teacher_mentions_mention_id_foreign` (`mention_id`),
  CONSTRAINT `teacher_mentions_mention_id_foreign` FOREIGN KEY (`mention_id`) REFERENCES `mentions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `teacher_mentions_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `teacher_mentions` WRITE;
/*!40000 ALTER TABLE `teacher_mentions` DISABLE KEYS */;
/*!40000 ALTER TABLE `teacher_mentions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `teacher_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teacher_subjects` (
  `teacher_id` bigint unsigned NOT NULL,
  `subject_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `teacher_subjects_teacher_id_foreign` (`teacher_id`),
  KEY `teacher_subjects_subject_id_foreign` (`subject_id`),
  CONSTRAINT `teacher_subjects_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `teacher_subjects_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `teacher_subjects` WRITE;
/*!40000 ALTER TABLE `teacher_subjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `teacher_subjects` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teachers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombreCompleto` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gradoAcademico` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` VALUES (1,'Delia Nina Huanca de Echegaray','Licenciada','2024-04-05 23:53:41','2024-04-05 23:53:41'),(2,'Rosario M. Camacho Meneses','Magister','2024-04-05 23:53:41','2024-04-05 23:53:41'),(3,'Edgar Chambi Gutierrez','Licenciado','2024-04-05 23:53:41','2024-04-05 23:53:41'),(4,'Nelson Isaac Chavez Perez','Licenciado','2024-04-05 23:53:41','2024-04-05 23:53:41'),(5,'Roberto E. Dalenz Cultrera','Doctor','2024-04-05 23:53:41','2024-04-05 23:53:41'),(6,'Rene Luis Delgado Aguirre','Doctor','2024-04-05 23:53:41','2024-04-05 23:53:41'),(7,'Juan Pablo Espinoza Conde','Licenciado','2024-04-05 23:53:41','2024-04-05 23:53:41'),(8,'Juana Iris Fernandez Tirado','Licenciada','2024-04-05 23:53:41','2024-04-05 23:53:41'),(9,'Erick Laime Pally','Licenciado','2024-04-05 23:53:41','2024-04-05 23:53:41'),(10,'Hugo Luis Ledezma Ruiz','Doctor','2024-04-05 23:53:41','2024-04-05 23:53:41'),(11,'Eulalia Mabel Marquez Villarroel','Licenciada','2024-04-05 23:53:41','2024-04-05 23:53:41'),(12,'Juan Carlos Medrano Barreda','Doctor','2024-04-05 23:53:41','2024-04-05 23:53:41'),(13,'Carla Millares Miashiro','Licenciada','2024-04-05 23:53:41','2024-04-05 23:53:41'),(14,'Silvia Eugenia Mita Kille','Doctora','2024-04-05 23:53:41','2024-04-05 23:53:41'),(15,'Lilian Orgaz Koppensteiner','Magister','2024-04-05 23:53:41','2024-04-05 23:53:41'),(16,'Lilia V. Francia de Peñaloza','Licenciada','2024-04-05 23:53:41','2024-04-05 23:53:41'),(17,'Rodolfo Poma Chuquimia','Licenciado','2024-04-05 23:53:41','2024-04-05 23:53:41'),(18,'Jose Edgar Pozzo Gonzales','Doctor','2024-04-05 23:53:41','2024-04-05 23:53:41'),(19,'Liliana Irma Trigo de Quintanilla','Licenciada','2024-04-05 23:53:41','2024-04-05 23:53:41'),(20,'Luis Silvestre G. Quiroga Mendieta','Doctor','2024-04-05 23:53:42','2024-04-05 23:53:42'),(21,'Antonio Rengel Sillerico','Doctor','2024-04-05 23:53:42','2024-04-05 23:53:42'),(22,'Carmen Angelica Revollo Yeilma','Licenciada','2024-04-05 23:53:42','2024-04-05 23:53:42'),(23,'Gabriela Clara Saavedra Iporre','Licenciada','2024-04-05 23:53:42','2024-04-05 23:53:42'),(24,'Sandra V. Salinas Murillo','Licenciada','2024-04-05 23:53:42','2024-04-05 23:53:42'),(25,'Javier Andrés Sucre Cadima','Licenciado','2024-04-05 23:53:42','2024-04-05 23:53:42'),(26,'Marlene Isabel Suxo Tejada','Licenciada','2024-04-05 23:53:42','2024-04-05 23:53:42'),(27,'Maria Lorena Torrico Queralt','Licenciada','2024-04-05 23:53:42','2024-04-05 23:53:42'),(28,'Edwin D. Trujillo Casanova','Doctor','2024-04-05 23:53:42','2024-04-05 23:53:42'),(29,'Javier Wilfredo Velasquez Sanchez','Licenciado','2024-04-05 23:53:42','2024-04-05 23:53:42'),(30,'Tatiana Alejandra Ajata Perez','Doctora','2024-04-05 23:53:42','2024-04-05 23:53:42'),(31,'Jhimy Butron Carlo','Licenciado','2024-04-05 23:53:42','2024-04-05 23:53:42'),(32,'Julio Antonio Caceres Catorety','Doctor','2024-04-05 23:53:42','2024-04-05 23:53:42'),(33,'Marie Rosario Fuentes Plata','Licenciada','2024-04-05 23:53:42','2024-04-05 23:53:42'),(34,'Rodolfo Cesar Tapia Coca','Licenciado','2024-04-05 23:53:42','2024-04-05 23:53:42'),(35,'Hernan Eliodoro Perez Saico','Ingeniero','2024-04-05 23:53:42','2024-04-05 23:53:42');
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=670 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,'Dpto. de Auditoria Interna','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(2,'Dpto. de Relaciones Internacionales','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(3,'Dpto. de Planificación, Evaluación y Acreditación (DPEC)','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(4,'División de Evaluación, Acreditación y Gestión de Calidad','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(5,'Dpto. de Información y Comunicación','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(6,'Televisión Universitaria','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(7,'Unidad de Transparencia','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(8,'Comisión de Cultura del HCU','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(9,'Comisión de Saneamiento Tec. Legal de Propiedades Universitarios','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(10,'Comisión de Infraestructura del HCU','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(11,'Defensoría Universitaria','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(12,'División de Apoyo al Norte Amazónico (DANA)','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(13,'UMSA Solidaria','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(14,'Seguro Social Universitario - SSU','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(15,'Radio San Andrés','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(16,'Programa de Cine y Producción Audiovisual','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(17,'VICERRECTORADO','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(18,'Secretaria Academica','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(19,'Dpto. de Personal Docente','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(20,'Div. de Escalafón y Curriculum Docente','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(21,'Fed. Sind. de Docentes de la UMSA (FEDSIDUMSA)','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(22,'Dpto. de Investigación Postgrado e Interacción Social (DIPGIS)','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(23,'Dpto. de Bienestar Social','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(24,'Div. de Trabajo Social','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(25,'Div. de Salud','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(26,'Sección de Becas Académicas','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(27,'Sección de Deportes','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(28,'Comisión Bienestar Social del HCU','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(29,'Centro Infantil Universitario Andresito','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(30,'Seccion de Cultura, Teatro y Coro','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(31,'Div. de Redes y Sistemas de Información','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(32,'Dpto. de Tecnologías de Información y Comunicación (DTIC)','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(33,'Div. de Sistemas de Información y Estadística','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(34,'Div. de Gestiones, Admisiones y Registros','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(35,'Div. de Biblioteca Central','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(36,'Inst. de Desarrollo Regional y Desconcentración Universitaria (IDR-DU)','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(37,'CIDES','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(38,'CIDES - Sub Dirección de Formación','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(39,'CIDES - Subdirección de Investigación','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(40,'CIDES - Subdirección de Interacción Social','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(41,'CIDES - Unidad de Administración Desconcentrada','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(42,'CEPIES','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(43,'CEPIES - Comunicación y Marketing','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(44,'CEPIES - Kardex','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(45,'CEPIES - Coordinación de Maestría y Diplomados','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(46,'CEPIES - Coordinación de Doctorado y Postdoctorado','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(47,'CEPIES - Area Desconcentrada','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(48,'CEPIES - Unidad de Sistemas','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(49,'CEPIES - Biblioteca','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(50,'CEPIES - Procuraduría','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(51,'CEPIES - METSIBO','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(52,'Sind. de Trabajadores de la UMSA (STUMSA)','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(53,'Consejo Académico Universitario - CAU','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(54,'SECRETARIA GENERAL','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(55,'Div. de Títulos y Diplomas','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(56,'Div. de Documentos y Archivo','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(57,'Div. de Desarrollo de Talento Humano','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(58,'Imprenta Universitaria','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(59,'Div. de Culturas y Artes','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(60,'Div. de Estratégias Comunicacionales','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(61,'Tribunal de Procesos Universitarios','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(62,'Tribunal de Garantias Electorales','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(63,'Administración Central','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(64,'DIRECCION ADMINISTRATIVA FINANCIERA','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(65,'Comisión Administrativa Financiera - HCU','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(66,'Dpto. de Presupuesto y Planificación Financiera','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(67,'Dpto. de Tesoro Universitario','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(68,'Caja Monoblock central','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(69,'Gestoría - Departamento Tesoro Universitario','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(70,'Sección Técnica de Operaciones Tributarias','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(71,'Dpto. de Contabilidad','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(72,'Archivo Contable','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(73,'Div. de Adquisiciones','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(74,'Almacén Central','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(75,'Div. de Bienes e Inventarios','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(76,'Dpto. de Recursos Humanos Administrativos','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(77,'Div. de Desarrollo de RRHH','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(78,'Div. de Acciones y Control','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(79,'Div. de Remuneraciones Administrativas','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(80,'Programa Permanente de Capacitación Administrativa - PPCAD','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(81,'Dpto. de Infraestructura','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(82,'Unidad de Transporte','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(83,'Área Desconcentrada de la Administración Central ADC','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(84,'Federación Universitaria Local (FUL)','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(85,'Federación Universitaria Local - HCU','Area central','2024-04-05 23:53:42','2024-04-05 23:53:42'),(86,'FCEF - Carrera Administración de Empresas - Biblioteca','Bibliotecas','2024-04-05 23:53:42','2024-04-05 23:53:42'),(87,'FCEF - Carrera de Economía - Biblioteca','Bibliotecas','2024-04-05 23:53:42','2024-04-05 23:53:42'),(88,'FAR - Biblioteca Especializada','Bibliotecas','2024-04-05 23:53:42','2024-04-05 23:53:42'),(89,'MED - Biblioteca central','Bibliotecas','2024-04-05 23:53:42','2024-04-05 23:53:42'),(90,'FODT - Biblioteca','Bibliotecas','2024-04-05 23:53:42','2024-04-05 23:53:42'),(91,'AGR - Biblioteca','Bibliotecas','2024-04-05 23:53:42','2024-04-05 23:53:42'),(92,'FAADU - Biblioteca (Arquitectura)','Bibliotecas','2024-04-05 23:53:42','2024-04-05 23:53:42'),(93,'FCG - Biblioteca','Bibliotecas','2024-04-05 23:53:42','2024-04-05 23:53:42'),(94,'FHCE - Biblioteca','Bibliotecas','2024-04-05 23:53:42','2024-04-05 23:53:42'),(95,'FDCP - Carrera de Derecho - Biblioteca','Bibliotecas','2024-04-05 23:53:42','2024-04-05 23:53:42'),(96,'ING - Biblioteca Central - Facultad de Ingeniería','Bibliotecas','2024-04-05 23:53:42','2024-04-05 23:53:42'),(97,'FHCE - Carrera de Psicología - Biblioteca','Bibliotecas','2024-04-05 23:53:42','2024-04-05 23:53:42'),(98,'TEC - Biblioteca Central','Bibliotecas','2024-04-05 23:53:42','2024-04-05 23:53:42'),(99,'FCPN - Carrera de Química','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(100,'FCPN - Carrera de Estadística','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(101,'FCPN - Centro de Estudiantes (Carrera de Estadistica)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(102,'FCPN - Carrera de Física','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(103,'FCPN - Planetario Max Schreier Observatorio Astronómico','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(104,'FCPN - Carrera de Informática','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(105,'FCPN - Centro de Estudiantes (Carrera de Informática)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(106,'FCPN - Centro de Estudiantes (Carrera de Matemática)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(107,'FCPN - Carrera de Matemática','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(108,'FCEF - Carrera Contaduría Pública','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(109,'FCEF - Carrera Contaduría Pública - Kardex','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(110,'FCEF - Carrera Contaduría Pública - Centro de Cómputo','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(111,'FCEF - Carrera Contaduría Pública - PETAENG','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(112,'FCEF - Carrera Contaduría Pública - Centro de Estudiantes','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(113,'FCEF - Carrera Contaduría Pública - Curso de Temporada','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(114,'FCEF - Carrera Administración de Empresas','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(115,'FCEF - Carrera Administración de Empresas - Centro de Estudiantes','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(116,'FCEF - Carrera Administración de Empresas - Kardex','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(117,'FCEF - Carrera Administración de Empresas - Centro de Cómputo','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(118,'FCEF - Carrera Administración de Empresas - Sede Provincial Caranavi','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(119,'FCEF - Carrera Administración de Empresas - Administración Montes','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(120,'FCEF - Carrera Administración de Empresas - CRU','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(121,'FCEF - Carrera Administración de Empresas - PETAENG','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(122,'FCEF - Carrera de Economía','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(123,'FCEF - Carrera de Economía - Kardex','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(124,'FCEF - Carrera de Economía - Centro de Cómputo','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(125,'FCEF - Carrera de Economía - Centro de Estudiantes','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(126,'FCEF - Carrera de Economía - PETAENG','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(127,'FAR - Carr. Química Farmaceútica','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(128,'FAR - Carr. Bioquímica','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(129,'MED - Carrera de Medicina','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(130,'MED - Comisión de Auto Evaluación y Acreditación del MERCOSUR','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(131,'MED - Carr. Enfermería','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(132,'MED - Carr. Nutrición y Dietética','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(133,'MED - Carr. Tecnología Médica','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(134,'FODT - Carr. Odontología','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(135,'AGR - CIPyCA (Dirección)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(136,'AGR - Carr. Ingeniería Agronómica','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(137,'AGR - CIPyCA (Administración Viacha)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(138,'TEC - Centro de Estudiantes - Carr. Elec. y Telecom','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(139,'FAADU - Carrera de Arquitectura','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(140,'ARQ - Re Acreditación Arquitectura','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(141,'FAADU - Carrera de Artes','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(142,'FAADU - Carrera Arquitectura - Centro de Estudiantes','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(143,'FCG - Carr. Ingeniería Geológica','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(144,'FCG - Honorable Consejo de Carrera (Carr. Ingeniería Geológica)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(145,'FCG - Carr. Ingeniería Geográfica','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(146,'FCG - Honorable Consejo de Carrera (Carr. Ingeniería Geográfica)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(147,'SOC - Carr. Trabajo Social','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(148,'SOC - Carr. Trabajo Social (Unidad de Prácticas)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(149,'SOC - Carr. Sociología','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(150,'SOC - Carr. Cs. de la Comunicación Social','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(151,'SOC - Carr. Antropología y Arqueología','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(152,'FDCP - Carrera de Derecho','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(153,'FDCP - Carrera de Derecho - Kardex','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(154,'FDCP - Carrera de Derecho - Secretaria Académica','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(155,'FDCP - Carrera de Derecho - Sistemas','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(156,'FDCP - Carrera de Derecho - Petaeng','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(157,'FDCP - Carrera de Derecho - Centro de Estudiantes','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(158,'FDCP - Carrera de Ciencias Políticas y Gestión Pública','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(159,'FDCP - CCPYGP - Kardex','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(160,'FDCP - CCPYGP - Sistemas','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(161,'FDCP - CCPYGP - Biblioteca','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(162,'FDCP - CCPYGP - Inst. Investigaciones en Ciencia Política (IINCIP)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(163,'FDCP - CCPYGP - Secretaría Académica','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(164,'FDCP - CCPYGP - Centro de Estudiantes','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(165,'FDCP - CCPYGP - PETAENG','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(166,'FHCE- Carr. Ciencias de la Información','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(167,'FHCE - Centro de Estudiantes (Carr. Cs. de la Información)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(168,'FHCE- Carr. Ciencias de la Educación','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(169,'FHCE - Centro de Estudiantes (Carr. Cs. de la Educación)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(170,'FHCE - Carr. Lingüistica e Idiomas','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(171,'FHCE - Centro de Enseñanza y Traducción de Idiomas (CETI)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(172,'FHCE - Prefacultativo Carr. Lingüistica','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(173,'FHCE - Carrera de Psicología','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(174,'FHCE - Kardex Carr. Psicología','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(175,'FHCE - Carera de Psicología - PETAENG','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(176,'FHCE - Centro de Estudiantes (Carrera de Psicología)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(177,'FHCE - Prefacultativo Carr. de Psicología','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(178,'FHCE - Carrera de Turismo','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(179,'FHCE - Centro de Estudiantes (Carr. Turismo)','Carreras','2024-04-05 23:53:42','2024-04-05 23:53:42'),(180,'FHCE - Prefacutltativo Carr. de Turismo','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(181,'FHCE - Carrera de Turismo - PETAENG','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(182,'FHCE - Carr. Historia','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(183,'FHCE - Centro de Estudiantes (Carr. Historia)','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(184,'ING - Carrera de Ingeniería Química','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(185,'ING - Carrera de Ingeniería Electrónica','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(186,'ING - Carrera de Ingeniería Eléctrica','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(187,'ING - Carrera de Ingeniería Industrial','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(188,'ING - Carrera de Ingeniería Mecánica','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(189,'ING - Carrera de Ingeniería Petrolera','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(190,'ING - Carrera de Ingeniería Civil','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(191,'ING - Carrera de Ingeniería Metalúrgica','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(192,'ING - Carrera de Ingeniería Mecánica y Electromecánica','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(193,'TEC - Carr. Electrónica y Telecomunicaciones','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(194,'TEC - Carr. Topografía Geodesia','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(195,'TEC - Carr. Electricidad','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(196,'TEC - Carr. Construcciones Civiles','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(197,'TEC - Centro de Estudiantes (Carr. Construcciones Civiles)','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(198,'TEC - Carr. Electromecánica','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(199,'TEC - Carr. Aeronáutica','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(200,'TEC - Carr. Mecánica Automotriz','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(201,'TEC - Carr. Quimica Industrial','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(202,'TEC - Carr. Mecánica Industrial','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(203,'TEC - Pre-facultativo Central','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(204,'TEC - Pre-facultativo Carrera Mecánica Automotriz ','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(205,'TEC - Pre-facultativo Carrera Electrónica y Telecomunicaciones','Carreras','2024-04-05 23:53:43','2024-04-05 23:53:43'),(206,'FAC. CIENCIAS PURAS Y NATURALES (Decanato)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(207,'FCPN - Vicedecanato','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(208,'FCPN - Kardex Facultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(209,'FCPN - Dirección de Admisión Facultativa','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(210,'FCPN - Unidad Desconcentrada','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(211,'FCPN - Unidad Desconcentrada de Infraestructura','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(212,'FCPN - Curso Pre Universitario','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(213,'FCPN - Centro de Estudiantes Facultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(214,'FAC. CS. ECONÓMICAS Y FINANCIERAS (Decanato)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(215,'FCEF - Vicedecanato','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(216,'FCEF - Honorable Consejo Facultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(217,'FCEF - Unidad Desconcentrada','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(218,'FCEF - Unidad de Infraestructura','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(219,'FCEF - Unidad de Sistemas','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(220,'FCEF - Unidad de Prefacultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(221,'FCEF - Unidad de Inventarios','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(222,'FCEF - Unidad Facultativa de Evaluación, Acreditación y Gestión de Calidad','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(223,'FCEF - Administracion de Bienes y Servicios','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(224,'FCEF - Centro de Estudiantes Facultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(225,'FCEF - Comisión de Postgrado Facultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(226,'FCEF - Comisión del Curso Prefacultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(227,'FCEF - Asociación de Docentes','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(228,'FAR - Maestría en Citología Aplicada: Diag. Diferencial y Molecular del Cáncer','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(229,'FAR - Fac. Cs. Farmaceúticas y Bioquímica (HCF)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(230,'FAC. CS. FARMACEUTICAS Y BIOQUIMICA (Decanato)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(231,'FAR - Vicedecanato','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(232,'FAR - Unidad Desconcentrada','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(233,'FAR - UDI','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(234,'FAR - CIDME','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(235,'FAR - ADBIOFAR','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(236,'FAR - Administración','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(237,'FAR - Secretario Eje. Carr. Quimica Farm.','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(238,'FAR - KARDEX','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(239,'FAR - Proyectos IDH','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(240,'FAR - Centro Facultativo Sec. Ejec. FCFB','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(241,'FAR - Secretario Eje. Carr. Bioquímica Farm.','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(242,'FAR - Sociedad Científica','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(243,'FAR - Farmacia Institucional','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(244,'FAR - Unidad de Sistemas','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(245,'FAR - Dpto. de Seguimiento Académico y Gestión de la Calidad','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(246,'FCFB - Unidad de Ensayos Biológicos - Biotero','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(247,'FCFB - CURSO PREFACULTATIVO','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(248,'FAC. MEDICINA (Decanato)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(249,'MED - FAC. MEDICINA (HCF)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(250,'MED - Vicedecanato','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(251,'MED - Unidad Desconcentrada','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(252,'MED - Caja','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(253,'MED - Departamento de Medicina','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(254,'MED - Departamento de Cirugía','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(255,'MED - Departamento de Materno Infantil','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(256,'MED - Departamento de Patologia','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(257,'MED - Departamento de Salud Publica','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(258,'MED - Departamento de Cs. Funcionales','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(259,'MED - Departamento de Cs. Morfológicas','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(260,'MED - Unidad de Biología Celular','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(261,'MED - (Unidad Desconcentrada Infraestructura) UDI','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(262,'MED - Oficina Revista Cuadernos','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(263,'MED - Inventarios','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(264,'MED - Almacenes','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(265,'MED - UMSALUD','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(266,'MED - Administración (I.B.B.A.)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(267,'MED - Administración','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(268,'MED - Librería OPS/OMS','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(269,'MED - Residencia Medica','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(270,'MED - Admisión Facultativa','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(271,'MED - Carrera de Medicina - Internado Rotatorio','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(272,'MED - Asociación Docentes ADMENT','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(273,'MED - Comisión Institucional del HCF','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(274,'MED - Comisión de Postgrado Facultativa','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(275,'MED - Comisión de Infraestructura del HCF','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(276,'MED - Comisión deConvenios del HCF','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(277,'MED - Comisión Administrativa Financiera del HCF','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(278,'MED - Comisión Administrativa Financiera CAF','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(279,'FAC. ODONTOLOGÍA (Decanato)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(280,'MED - Comisión de Tecnología de Comunicación del HCF','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(281,'MED - Comisión de Investigación e Interacción Social del HCF','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(282,'FODT - Vicedecanato','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(283,'MED - Comité de Ética en la Investigación y Calidad COMETICA','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(284,'MED - Prefacultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(285,'FODT - Unidad Desconcentrada','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(286,'MED - Proyecto TOURO','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(287,'MED - Sistema de Adminisión Facultativo S.A.F.','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(288,'MED - Centro de Estudiantes Facultativo CEFACMENT','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(289,'MED - Unidad del Proceso de Admisión','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(290,'MED - Oficina de Educación Médica y Gestión de Calidad','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(291,'FODT - ADOFO','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(292,'FODT - Unidad Técnica','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(293,'FODT - Kardex Facultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(294,'FODT - Unidad de Admisión Estudiantil Facultativa','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(295,'FODT - Administración Estudiantil Facultativa','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(296,'FODT - Unidad de Informática','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(297,'FODT - Administración','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(298,'FODT - Unidad de Inventarios','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(299,'FODT - Unidad de Radiología','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(300,'FODT - Unidad de Infraestructura','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(301,'FODT - Almacenes','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(302,'FODT - Inst. de Investigación y Desarrollo de la Facultad de Odontología IIDFO','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(303,'FODT - Comisión de Proceso de Autoeval. Acred. ARCU - SUR','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(304,'FODT - Unidad Gestión y Seguimiento de la Calidad','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(305,'FAC. AGRONOMIA (Decanato)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(306,'AGR - Vicedecanato','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(307,'AGR - UDAF','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(308,'AGR - Curso Prefacultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(309,'AGR - Maestría en Ingeniería de Riegos','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(310,'AGR - Centro de Estudiantes Facultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(311,'AGR - Centro de Estudiantes Carr. Agronomia','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(312,'AGR - Centro de Estudiantes Cipyca','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(313,'AGR - Implementacion de Riego por aspercion','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(314,'AGR - Centro Experiemental (cota cota)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(315,'AGR - Programa en Ingeniería Agronómica Tropical','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(316,'AGR - Programa en Medicina Veterinaria y Zootécnia','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(317,'AGR - Capacitacion','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(318,'AGR - Programa en Ingeniería Agronómica Forestal','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(319,'AGR - Estacion Experimental de Choquenaira','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(320,'AGR - Estación Experimental de Patacamaya','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(321,'AGR - Sistemas','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(322,'AGR - Estacion Experimental de Sapecho','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(323,'AGR - Proyecto Estimación de Estudios Ambientales','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(324,'AGR - Petaeng','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(325,'AGR - Administración','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(326,'AGR - Kardex','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(327,'AGR - UDI','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(328,'AGR - ADAG Asoc. de Docentes de Agro.','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(329,'AGR - Unidad de Difusión y Comunicación','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(330,'AGR - CRU Patacamaya - SUR Luribay','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(331,'AGR - Unidad de Gestión y Seguimiento de la Calidad Académica','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(332,'FAC. ARQUITECTURA Y ARTES (Decanato)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(333,'FAADU - Vicedecanato','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(334,'FAADU - Centro de Recursos Tecnológicos Y Pedagógicos - CRTP','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(335,'FAADU - Administración','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(336,'FAADU - Infraestructura','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(337,'FAADU - Kardex Arquitectura','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(338,'FAADU - Inventarios','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(339,'FAADU - Área Desconcentrada','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(340,'FAADU - Programa de Admisión Facultativa','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(341,'FAADU - Imprenta y Publicaciones','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(342,'FAC. CS.GEOLOGICAS (Decanato)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(343,'FCG - Vicedecanato','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(344,'FCG - Área Desconcentrada','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(345,'FCG - Unidad Desconcentrada de Infraestructura','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(346,'FCG - Depósito','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(347,'FCG - Administración de Bienes e Inventarios','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(348,'FCG - Curso Prefacultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(349,'FCG - Administración','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(350,'FCG - Honorable Consejo Facultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(351,'FCG - Archivo (Decanato)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(352,'FCG - Kardex','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(353,'FCG - Centro de Estudiantes Fac. Ciencias Geológicas','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(354,'FCG - Unidad de Sistemas','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(355,'FCG - Centro de Estudiantes Carr. Ingeniería Geológica','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(356,'FCG - Centro de Estudiantes Carr. Ingeniería Geográfica','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(357,'FCG - Maestría en Geopolítica de los Recursos Naturales','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(358,'FCG - Maestria en Teledetección Espacial y Sist. de Información Geográfica Aplicadas a las Ciencias de la Tierra','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(359,'FCG - Programa Académico Desconcentrado Quime','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(360,'FCG - Programa Académico Desconcentrado Caranavi','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(361,'FCG - Programa Académico Desconcentrado Achacachi','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(362,'FCG - Programa Académico Desconcentrado VIACHA','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(363,'FAC. CS. SOCIALES (Decanato)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(364,'FAC. CS. SOCIALES (HCF)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(365,'SOC - Vicedecanato','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(366,'SOC - (Unidad Desconcentrada Infraestructura) UDI','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(367,'SOC - Unidad de Área Desconcentrada','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(368,'SOC - Administración','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(369,'SOC - Inventariador Fac. Cs. Sociales','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(370,'SOC - de Admisión Facultativa','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(371,'SOC - Observatorio de Políticas Públicas Sociales','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(372,'SOC - Asociación de Docentes','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(373,'SOC - Centro de Estudiantes Carr. Trabajo Social','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(374,'SOC - Centro de Estudiantes Carr. Cs. Com. Social','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(375,'FAC. DERECHO Y CS.POLITICAS (Decanato)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(376,'FDCP - Secretaría Académica Facultativa','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(377,'FDCP - Vicedecanato','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(378,'FDCP - Unidad de Administración Desconcentrada (UAD)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(379,'FDCP - Unidad Desconcentrada de Infraestructura','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(380,'FDCP - Unidad de Inventarios','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(381,'FDCP - Centro de Estudiantes Facultativo','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(382,'FDCP - Unidad de Administración Facultativa','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(383,'FDCP - Instituto de Práctica Forense','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(384,'FDCP - Dirección de Admisión Facultativa','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(385,'Centro de Conciliación Facultativo - FDCP','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(386,'CENTRO INFANTIL UNIVERSITARIO \"ISIDORITO\"','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(387,'FHCE - Ventanilla Facultativa','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(388,'FAC. HUM. Y CS. DE LA EDUCACIÓN (Decanato)','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(389,'FHCE - Vicedecanato','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(390,'FHCE - Administración','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(391,'FHCE - Asociación de Docentes','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(392,'FHCE - Área Desconcentrada','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(393,'FHCE - UDI','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(394,'FHCE- Unidad de Sistemas','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(395,'FHCE - Inventarios','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(396,'FHCE - Imprenta','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(397,'FHCE - Círculo Infantil','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(398,'FHCE - Diagnóstico Neuropedagógico','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(399,'FHCE - Coordinación Facultativa','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(400,'FHCE - Unidad de Postgrado','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(401,'FHCE - Autoeval. y Acreditación','Facultades','2024-04-05 23:53:43','2024-04-05 23:53:43'),(402,'FHCE - Internacionalización','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(403,'FHCE - Adulto Mayor','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(404,'FHCE - Unidad de Comunicación','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(405,'FHCE - Equinoterapia','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(406,'FDCP - Programa Derecho de las Naciones Originarias','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(407,'FDCP - TIC Facultativo','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(408,'FAC. INGENIERIA (Decanato)','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(409,'FDCP - Maestría en Educación Superior con Enfoque Intercultural Jurídico y Político','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(410,'FDCP - Asociación de Docentes','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(411,'FDCP - Unidad de Gestión de Planif. y Seguimiento de la Calidad','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(412,'ING - Vicedecanato','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(413,'ING - Unidad Desconcentrada','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(414,'ING - Cursos Básicos','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(415,'FHCE - Instituto de Investigación, Interacción y Postgrado de Psicología','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(416,'ING - Unidad de Sistemas','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(417,'FHCE - Archivo La Paz','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(418,'FAC. DE TECNOLOGIA (Decanato)','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(419,'TEC - Centro de Estudiantes Facultativa','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(420,'TEC - Asociación Docentes (ADOFATEC)','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(421,'TEC - Vicedecanato','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(422,'TEC - Unidad Desconcentrada','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(423,'TEC - (Unidad Desconcentrada Infraestructura) UDI','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(424,'TEC - Kardex','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(425,'ING - Instituto de Ingeniería Sanitaria Ambiental','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(426,'TEC - Dirección y Coordinación','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(427,'TEC - Dpto. de Materias Básicas','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(428,'TEC - Adminisración (Potosí)','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(429,'TEC - Administración (Arce)','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(430,'TEC - Curso de Temporada','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(431,'TEC - Dpto. de Computación','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(432,'TEC - Sede Provincial Achacachi','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(433,'ING - Organización de Estudiantes de Ingeniería','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(434,'TEC - Sede Provincial Colquencha','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(435,'TEC - Sede Provincial Irupana','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(436,'TEC - LABOTECC','Facultades','2024-04-05 23:53:44','2024-04-05 23:53:44'),(437,'Instituciones Externas a la UMSA','Institucion externa','2024-04-05 23:53:44','2024-04-05 23:53:44'),(438,'FCPN - Instituto de Biología Herbario','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(439,'FCPN - Instituto de investigaciones Físicas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(440,'FCPN - Instituto de Investigaciones de Informática','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(441,'FCPN - Instituto de Investigaciones Químicas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(442,'IIQ - Laboratorio de Resonancia Magnética Nuclear','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(443,'IIQ - Laboratorio de Análisis de Química Ambiental','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(444,'IIQ - Laboratorio de Análisis de Alimentos','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(445,'IIQ - Laboratorio de Cromatografía de Gases','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(446,'IIQ - Laboratorio Nro. 1 Servicio de Análisis','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(447,'IIQ - Laboratorio de Servicio de Química de Materiales, Catálisis y Petroquímica','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(448,'FCPN - Instituto de Investigaciones de Calidad Ambiental','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(449,'FCPN - Instituto de Ecología','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(450,'FCPN - Instituto de Biología Molecular y Biotecnología','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(451,'FCPN - Instituto de Estadística Teórica y Aplicada','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(452,'FCPN - Jardín Botánico','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(453,'FCEF - (IICCFA) Inst. en Inv. en Cs. Contables, Financieras y Auditoria','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(454,'FCEF - IICCA','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(455,'FCEF - Instituto de Investigaciones Económicas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(456,'FAR - SELADIS - Servicio de Laboratorio y Diagnóstico','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(457,'FAR - SELADIS - Servicio de Laboratorio y Diagnóstico - Zona Central','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(458,'FAR - SELADIS - Servicio de Laboratorio y Diagnóstico - Zona Sur','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(459,'FAR - SELADIS - Laboratorio de Virología','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(460,'FAR - SELADIS - Laboratorio de Biomedicina Experimental','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(461,'FAR - SELADIS - Laboratorio Histocompatibilidad','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(462,'FAR - SELADIS - Laboratorio de Genética Molecular','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(463,'FAR - SELADIS - Laboratorio de Bromatología','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(464,'FAR - SELADIS - Laboratorio de Microbiología Molecular','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(465,'FAR - SELADIS - Control de Calidad de Medicamentos y Cosméticos','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(466,'FAR - SELADIS - Laboratorio de Biodisponibilidad y Bioequivalencia','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(467,'FAR - SELADIS - Laboratorio de Endocrinologia','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(468,'FAR - SELADIS - Laboratorio de Bacteriología','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(469,'FAR - SELADIS - Laboratorio de Microbiología de Alimentos','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(470,'FAR - SELADIS - Laboratorio de Química Clínica','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(471,'FAR - SELADIS - Laboratorio de Hematología','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(472,'FAR - SELADIS - Laboratorio de Parasitología','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(473,'FAR - SELADIS - Laboratorio de Inmunología','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(474,'FAR - SELADIS - Laboratorio de Citología','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(475,'FAR - SELADIS - Unidad de Sistemas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(476,'FAR - SELADIS - Trabajo Social','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(477,'FAR - SELADIS - AdminIstración','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(478,'FAR - SELADIS - Asesoria Legal','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(479,'FAR - SELADIS - Cajas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(480,'FAR - Inst. de Inv. Farmaco y Bioquímica (IIFB)','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(481,'MED - Instituto de Genética','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(482,'MED - Instituto de Genética','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(483,'MED - Inst. de Inv. En Salud y Desarrollo - IINSAD','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(484,'MED - Instituto Boliviano de Biología de Altura I.B.B.A.','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(485,'AGR - Instituto de Inv. Agropecuarias y Recursos Naturales','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(486,'FAADU - Instituto de Investigación y Postgrado','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(487,'FCG - Instituto de Investigaciones Geológicas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(488,'FCG - Instituto de Investigaciones Geográficas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(489,'SOC - Instituto de Invs. Antropológicas y Arqueológicas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(490,'SOC - Instituto de Investigaciones Sociológicas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(491,'SOC - Instituto IPICOM','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(492,'FDCP - Instituto de Investigaciones, Seminarios y Tesis','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(493,'FDCP - Instituto de Seminario derecho','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(494,'FHCE - Inst. de Investigaciones de Psicología','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(495,'FHCE - Inst. de Inv., Consultoria y Serv. Turísticos - IICSTUR','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(496,'FHCE - Inst. de Inv. , Postgrado e Interacción Social IIPIST','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(497,'FHCE - Emprendimiento de Inf. y Serv. Turísticos - EMISTUR','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(498,'FHCE - Instituto de Estudios Bolivianos (IEB)','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(499,'FHCE - Inst. de Investigaciones Históricas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(500,'ING - Instituto de Investigaciones Amazónicas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(501,'ING - Instituto de Electrónica Aplicada','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(502,'ING - Instituto de Investigaciones Industriales','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(503,'ING - Instituto de Investigaciones Mecánicas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(504,'ING - Instituto de Investigaciones Metalúrgicas y de Materiales','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(505,'ING - Instituto de Ensayo de Materiales','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(506,'ING - Instituto de Hidráulica e Hidrología','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(507,'ING - Instituto de Investigación y Desarrollo de Procesos Químicos','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(508,'ING - Instituto INUISISO','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(509,'ING - Postgrado Ingeniería Sanitara','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(510,'ING - Instituto de Transporte y Vías de Comunicación','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(511,'ING - Postgrado en Gestión Sost. Recursos Hídricos','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(512,'TEC - Instituto de Inv., Producción y Asistencia Técnica','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(513,'TEC - Instituto de Inv. y Aplicaciones Tecnológicas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(514,'TEC - Instituto de Inv. y Aplicaciones Geomáticas','Institutos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(515,'AGR - ProyectoIllimani','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(516,'AGR - Proyecto Forrajes','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(517,'AGR - Proyecto Fontagro','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(518,'AGR - Proyecto Andescrop','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(519,'AGR - Proyecto Quinagua','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(520,'AGR - Proyecto OTB \"La Algarrobilla\"','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(521,'AGR - Proyectos IDH','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(522,'AGR - Proyecto CBA - Batallas','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(523,'AGR - Proyecto Presas Sub Terraneas','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(524,'AGR - Proyecto Cultivos Andinos','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(525,'AGR - Proyecto la Universidad con las comunidades rurales','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(526,'AGR - Proyecto Fisar','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(527,'AGR - Proyecto Megeovit','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(528,'AGR - Proyecto Crianza de Cuyes','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(529,'AGR - Proyecto de Pucarani','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(530,'TEC - Proyecto Aceites','Proyectos','2024-04-05 23:53:44','2024-04-05 23:53:44'),(531,'FCPN - Postgrado Ecología y Conservación','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(532,'FCPN - Postgrado Informática','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(533,'FCPN - Postgrado Matemática','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(534,'FCEF - Carrera Contaduría Pública - Unidad de Postgrado','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(535,'FCEF - Carrera Administración de Empresas - Unidad de Postgrado','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(536,'FCEF - Postgrado Auditoria','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(537,'FCEF - Postgrado Economía','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(538,'FAR - Postgrado Bioquímica','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(539,'MED - Unidad de Postgrado','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(540,'MED - Postgrado Nutrición','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(541,'FODT - Postgrado','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(542,'AGR - Postgrado Agronomía','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(543,'FAADU - Postgrado Arquitectura','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(544,'FCG - Postgrado Carrera Ingeniería Geográfica ','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(545,'FCG - Postgrado Cs. Geológicas','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(546,'SOC - Postgrado IPICOM','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(547,'FDCP - Postgrado y Relaciones Internacionales','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(548,'FDCP - Área de Ciencias Políticas (UPRI)','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(549,'FDCP - Área Financiera (UPRI)','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(550,'FDCP - Área Kardex (UPRI)','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(551,'FDCP - Área Secretaria Académica (UPRI)','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(552,'FDCP - Área Sistemas (UPRI)','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(553,'FDCP - Área de Derecho (UPRI)','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(554,'FHCE - Postgrado de Ciencias de la Educación','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(555,'FHCE - Postgrado de Psicología','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(556,'ING - Postgrado en Redes de Comunicación','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(557,'ING - Postgrado Estructuras','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(558,'ING - Postgrado Ingeniería Industrial','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(559,'ING - Postgrado IQPAA','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(560,'TEC - UNIDAD DE POSTGRADO','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(561,'TEC - Coordinación del Programa de Maestría','Unidad de posgrado','2024-04-05 23:53:44','2024-04-05 23:53:44'),(562,' Instituto de Desarrollo Regional','Unidad externa','2024-04-05 23:53:44','2024-04-05 23:53:44'),(563,'TInst. de Desarrollo Regional y Desconcentración Universitaria IDR-DU (Administración)','Unidad externa','2024-04-05 23:53:44','2024-04-05 23:53:44'),(564,'Administración Central','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(565,'Almacén Central','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(566,'Caja Monoblock central','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(567,'Centro Infantil Universitario Andresito','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(568,'CEPIES','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(569,'Comisión Administrativa Financiera - HCU','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(570,'Comisión Bienestar Social del HCU','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(571,'Comisión de Cultura del HCU','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(572,'Comisión de Infraestructura del HCU','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(573,'Comisión de Saneamiento Tec. Legal de Propiedades Universitarios','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(574,'Consejo Académico Universitario - CAU','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(575,'Defensoría Universitaria','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(576,'DIRECCION ADMINISTRATIVA FINANCIERA','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(577,'Div. de Acciones y Control','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(578,'Div. de Adquisiciones','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(579,'Div. de Biblioteca Central','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(580,'Div. de Bienes e Inventarios','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(581,'Div. de Culturas y Artes','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(582,'Div. de Desarrollo de RRHH','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(583,'Div. de Desarrollo de Talento Humano','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(584,'Div. de Documentos y Archivo','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(585,'Div. de Escalafón y Curriculum Docente','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(586,'Div. de Estratégias Comunicacionales','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(587,'Div. de Gestiones, Admisiones y Registros','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(588,'Div. de Remuneraciones Administrativas','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(589,'Div. de Salud','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(590,'Div. de Títulos y Diplomas','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(591,'Div. de Trabajo Social','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(592,'División de Apoyo al Norte Amazónico (DANA)','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(593,'División de Evaluación, Acreditación y Gestión de Calidad','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(594,'Dpto. de Asesoria Juridica','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(595,'Dpto. de Auditoria Interna','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(596,'Dpto. de Bienestar Social','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(597,'Dpto. de Contabilidad','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(598,'Dpto. de Información y Comunicación','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(599,'Dpto. de Infraestructura','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(600,'Dpto. de Investigación Postgrado e Interacción Social (DIPGIS)','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(601,'Dpto. de Personal Docente','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(602,'Dpto. de Planificación, Evaluación y Acreditación (DPEC)','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(603,'Dpto. de Presupuesto y Planificación Financiera','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(604,'Dpto. de Recursos Humanos Administrativos','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(605,'Dpto. de Relaciones Internacionales','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(606,'Dpto. de Tecnologías de Información y Comunicación (DTIC)','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(607,'Dpto. de Tesoro Universitario','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(608,'Fed. Sind. de Docentes de la UMSA (FEDSIDUMSA)','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(609,'Federación Universitaria Local (FUL)','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(610,'Gestoría - Departamento Tesoro Universitario','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(611,'Imprenta Universitaria','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(612,'Inst. de Desarrollo Regional y Desconcentración Universitaria (IDR-DU)','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(613,'Programa de Cine y Producción Audiovisual','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(614,'Programa Permanente de Capacitación Administrativa - PPCAD','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(615,'Radio San Andrés','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(616,'RECTORADO','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(617,'Sección de Deportes','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(618,'Sección Técnica de Operaciones Tributarias','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(619,'Secretaria Academica','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(620,'SECRETARIA GENERAL','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(621,'Seguro Social Universitario - SSU','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(622,'Sind. de Trabajadores de la UMSA (STUMSA)','Externo central','2024-04-05 23:53:44','2024-04-05 23:53:44'),(623,'Televisión Universitaria','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(624,'Tribunal de Garantias Electorales','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(625,'Tribunal de Procesos Universitarios','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(626,'UMSA Solidaria','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(627,'Unidad de Transparencia','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(628,'Unidad de Transporte','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(629,'VICERRECTORADO','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(630,'CEPIES - Coordinación de Doctorado y Postdoctorado','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(631,'CEPIES - Area Desconcentrada','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(632,'CEPIES - Unidad de Sistemas','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(633,'CEPIES - Biblioteca','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(634,'CEPIES - Procuraduría','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(635,'CEPIES - METSIBO','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(636,'Sind. de Trabajadores de la UMSA (STUMSA)','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(637,'Consejo Académico Universitario - CAU','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(638,'SECRETARIA GENERAL','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(639,'Div. de Títulos y Diplomas','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(640,'Div. de Documentos y Archivo','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(641,'Div. de Desarrollo de Talento Humano','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(642,'Imprenta Universitaria','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(643,'Div. de Culturas y Artes','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(644,'Div. de Estratégias Comunicacionales','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(645,'Tribunal de Procesos Universitarios','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(646,'Tribunal de Garantias Electorales','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(647,'Administración Central','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(648,'DIRECCION ADMINISTRATIVA FINANCIERA','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(649,'Comisión Administrativa Financiera - HCU','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(650,'Dpto. de Presupuesto y Planificación Financiera','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(651,'Dpto. de Tesoro Universitario','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(652,'Caja Monoblock central','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(653,'Gestoría - Departamento Tesoro Universitario','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(654,'Sección Técnica de Operaciones Tributarias','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(655,'Dpto. de Contabilidad','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(656,'Archivo Contable','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(657,'Div. de Adquisiciones','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(658,'Almacén Central','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(659,'Div. de Bienes e Inventarios','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(660,'Dpto. de Recursos Humanos Administrativos','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(661,'Div. de Desarrollo de RRHH','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(662,'Div. de Acciones y Control','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(663,'Div. de Remuneraciones Administrativas','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(664,'Programa Permanente de Capacitación Administrativa - PPCAD','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(665,'Dpto. de Infraestructura','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(666,'Unidad de Transporte','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(667,'Área Desconcentrada de la Administración Central ADC','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(668,'Federación Universitaria Local (FUL)','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45'),(669,'Federación Universitaria Local - HCU','Externo central','2024-04-05 23:53:45','2024-04-05 23:53:45');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ci` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombres` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidoPaterno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidoMaterno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imagen` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resetear` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_ci_unique` (`ci`),
  UNIQUE KEY `users_imagen_unique` (`imagen`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'8441659','Enrique L.','Barra','Paredes','administrador','activo','adminFoto.jpg','$2y$12$N1gPYuOWzkXoXifTIeT46eRY/9uWE6Eds13IQzZqke.UAV6JUVAz2','2001-05-03','barra.paredes.enrique.luis@gmail.com','0',NULL,NULL,'2024-04-05 23:53:45','2024-04-05 23:53:45'),(3,'8441658','Roberto','Ayal','Ma','administrativo','activo','jKg9eTVpFmMsiapaQ5NvBFAkxnbZahOB0qCi.jpg','$2y$12$2Knws1rzdMIquRyGktI.1ehvv3QeyqSYzsgjpx3Jok07UToafTl9m','2024-04-05','roberto@gmail.com','0',NULL,NULL,'2024-04-05 23:55:58','2024-04-06 00:59:50'),(4,'8441657','Estudiante 1','Estudiante','Estudiante','estudiante','activo','aMXjYktOlaPuIoP6k9SwYPT3CAQhYM2khIMG.png','$2y$12$0YelPGjnm1UnDeCowgpi5O5YrPgnZZdycvHzB6YI8hZpXj0BLGxTW','2024-04-04','estudiante@gmail.com','0',NULL,NULL,'2024-04-06 01:13:32','2024-04-06 01:15:17');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

